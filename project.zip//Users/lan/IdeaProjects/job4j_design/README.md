#job4j_design
[![Build Status](https://travis-ci.com/alaktyushin/job4j_design.svg?branch=master)](https://travis-ci.com/alaktyushin/job4j_design)
[![codecov](https://codecov.io/gh/alaktyushin/job4j_design/branch/master/graph/badge.svg?token=6GJ7KCBIUB)](https://codecov.io/gh/alaktyushin/job4j_design)
